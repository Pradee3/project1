package com.cg.ars.controller;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.NoResultException;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ars.dto.BookingInformationDTO;
import com.cg.ars.dto.BookingsDbDTO;
import com.cg.ars.dto.FlightInformationDTO;
import com.cg.ars.dto.LoginTypeDTO;
import com.cg.ars.dto.SearchDTO;
import com.cg.ars.dto.SearchResultDTO;
import com.cg.ars.exception.ARSException;
import com.cg.ars.service.IAirlineService;

@Controller
public class ARSController {

	@Autowired
	IAirlineService airSer;

	@RequestMapping(value = "login", method = RequestMethod.GET)
	public String loginPg(@ModelAttribute("loginmy") LoginTypeDTO loginType,
			FlightInformationDTO flight, BindingResult result,
			Map<String, Object> model) {
		return "loginPg";
	}

	@RequestMapping(value = "logout", method = RequestMethod.GET)
	public String logoutPg(@ModelAttribute("loginmy") LoginTypeDTO loginType,
			FlightInformationDTO flight, BindingResult result,
			Map<String, Object> model) {
		int status=1;
		model.put("status",status );
		return "loginPg";
	}
	
	@RequestMapping(value="userLogin",method=RequestMethod.POST)
	public ModelAndView login(@ModelAttribute("loginmy") LoginTypeDTO loginType,@ModelAttribute("FlightSearch") SearchDTO search, @ModelAttribute("my")FlightInformationDTO flight, BindingResult result,Map<String,Object> model) throws ARSException{
		/*LoginTypeDTO loginType=new LoginTypeDTO();*/
		String log1 = "USER";
		String log2 = "ADMIN";
		String log3 = "EXECUTIVE";
		String flag = "Not Available";
		String username=loginType.getUsername();
		String password=loginType.getPassword();
		model.put("uname",username );
		if(result.hasErrors()){
			return new ModelAndView ("loginPg","msg","Invalid LoginCredentials");
		}
		else{
			try{
			loginType=airSer.login(username);
			if(loginType!=null){
				if(loginType.getPassword().equals(password)){
					if(loginType.getRole().equals(log1)){

						List<String> myCities=new ArrayList<String>();
						
						myCities.add("CHENNAI");
						myCities.add("PUNE");
						myCities.add("MUMBAI");
						myCities.add("DELHI");
						
						model.put("myCities",myCities );
						
						List<String> arsClass=new ArrayList<String>();
						
						arsClass.add("FC");
						arsClass.add("Business");
						
						model.put("arsClass",arsClass );
						
						return new ModelAndView ("userPgOne");
					}else if(loginType.getRole().equals(log2)){
						return new ModelAndView("AdminMenus");
					}else if(loginType.getRole().equals(log3)){
						return new ModelAndView("executive");
					}
					else{
						return new ModelAndView ("loginPg","msg","Invalid LoginCredentials");
					}
			}else{
				return new ModelAndView ("loginPg","msg","Invalid LoginCredentials");
			}		
		}else{
			return new ModelAndView ("loginPg","msg","Invalid LoginCredentials");
		}
			
		}
		catch(Exception e){
			return new ModelAndView ("loginPg","msg","Invalid LoginCredentials");
		}
		}
	}

	
	
	@RequestMapping(value = "signUp", method = RequestMethod.GET)
	public String signUpPg(@ModelAttribute("signupmy") LoginTypeDTO loginType,
			BindingResult result, Map<String, Object> model) {

		return "signUp";
	}

	@RequestMapping(value = "signUp", method = RequestMethod.POST)
	public ModelAndView signUp(
			@Valid @ModelAttribute("signupmy") LoginTypeDTO loginType,
			@ModelAttribute("FlightSearch") SearchDTO search,
			BindingResult result, Map<String, Object> model)
			throws ARSException {

		if (result.hasErrors()) {
			return new ModelAndView("signUp");

		} else {
			String uname = loginType.getUsername();

			List<String> myCities = new ArrayList<String>();

			myCities.add("CHENNAI");
			myCities.add("PUNE");
			myCities.add("MUMBAI");
			myCities.add("DELHI");

			model.put("myCities", myCities);

			List<String> arsClass = new ArrayList<String>();

			arsClass.add("FC");
			arsClass.add("Business");

			model.put("arsClass", arsClass);

			airSer.signUp(loginType);
			return new ModelAndView("userPgOne", "uname", uname);

		}

	}

	@RequestMapping(value = "BackUser", method = RequestMethod.POST)
	public ModelAndView userBack(
			@Valid 
			@ModelAttribute("FlightSearch") SearchDTO search,
			BindingResult result, Map<String, Object> model)
			throws ARSException {

		if (result.hasErrors()) {
			
			List<String> myCities = new ArrayList<String>();

			myCities.add("CHENNAI");
			myCities.add("PUNE");
			myCities.add("MUMBAI");
			myCities.add("DELHI");

			model.put("myCities", myCities);

			List<String> arsClass = new ArrayList<String>();

			arsClass.add("FC");
			arsClass.add("Business");

			model.put("arsClass", arsClass);
			
			return new ModelAndView("userPgOne");

		} else {
			

			List<String> myCities = new ArrayList<String>();

			myCities.add("CHENNAI");
			myCities.add("PUNE");
			myCities.add("MUMBAI");
			myCities.add("DELHI");

			model.put("myCities", myCities);

			List<String> arsClass = new ArrayList<String>();

			arsClass.add("FC");
			arsClass.add("Business");

			model.put("arsClass", arsClass);

			
			return new ModelAndView("userPgOne");

		}

	}
	
	@RequestMapping(value = "Menu Add Flights", method = RequestMethod.GET)
	public String addData(@ModelAttribute("my") FlightInformationDTO flight,
			BindingResult result, Map<String, Object> model) {

		List<String> myCategory = new ArrayList<String>();

		myCategory.add("AIRLINE1");
		myCategory.add("AIRLINE2");
		myCategory.add("AIRLINE3");
		myCategory.add("AIRLINE4");

		model.put("myList", myCategory);

		List<String> myCities = new ArrayList<String>();

		myCities.add("CHENNAI");
		myCities.add("PUNE");
		myCities.add("MUMBAI");
		myCities.add("DELHI");

		model.put("myCities", myCities);

		return "AdminAddFlights";
	}

	@RequestMapping(value = "addflights", method = RequestMethod.GET)
	public ModelAndView dataAdd(
			@Valid @ModelAttribute("my") FlightInformationDTO flight,
			BindingResult result, Map<String, Object> model)
			throws ARSException {

		if (result.hasErrors()) {

			List<String> myCategory = new ArrayList<String>();

			myCategory.add("AIRLINE1");
			myCategory.add("AIRLINE2");
			myCategory.add("AIRLINE3");
			myCategory.add("AIRLINE4");

			model.put("myList", myCategory);

			List<String> myCities = new ArrayList<String>();

			myCities.add("CHENNAI");
			myCities.add("PUNE");
			myCities.add("MUMBAI");
			myCities.add("DELHI");

			model.put("myCities", myCities);

			return new ModelAndView("AdminAddFlights");

		} else {
			try{
			System.out.println(flight);
			airSer.insertFlight(flight);
			return new ModelAndView("success", "pid", "Inserted");
			}
			catch(Exception e){
				List<String> myCategory = new ArrayList<String>();

				myCategory.add("AIRLINE1");
				myCategory.add("AIRLINE2");
				myCategory.add("AIRLINE3");
				myCategory.add("AIRLINE4");

				model.put("myList", myCategory);

				List<String> myCities = new ArrayList<String>();

				myCities.add("CHENNAI");
				myCities.add("PUNE");
				myCities.add("MUMBAI");
				myCities.add("DELHI");

				model.put("myCities", myCities);
				
				return new ModelAndView("AdminAddFlights", "pid", "Sorry, Flight already exits in this number!");
			}
			// return "success";
		}

	}

	@RequestMapping(value = "SearchPg", method = RequestMethod.GET)
	public String searchPg(@ModelAttribute("FlightSearch") SearchDTO search,
			BindingResult result, Map<String, Object> model) {

		List<String> myCities = new ArrayList<String>();

		myCities.add("CHENNAI");
		myCities.add("PUNE");
		myCities.add("MUMBAI");
		myCities.add("DELHI");

		model.put("myCities", myCities);

		List<String> arsClass = new ArrayList<String>();

		arsClass.add("FC");
		arsClass.add("Business");

		model.put("arsClass", arsClass);

		return "userPgOne";
	}

	@RequestMapping(value = "Search", method = RequestMethod.POST)
	public ModelAndView flightSearch(
			@Valid @ModelAttribute("FlightSearch") SearchDTO search,
			BindingResult result, Map<String, Object> model)
			throws ARSException {

		if (result.hasErrors()) {

			List<String> myCities = new ArrayList<String>();

			myCities.add("CHENNAI");
			myCities.add("PUNE");
			myCities.add("MUMBAI");
			myCities.add("DELHI");

			model.put("myCities", myCities);
			List<String> arsClass = new ArrayList<String>();

			arsClass.add("FC");
			arsClass.add("Business");

			model.put("arsClass", arsClass);

			return new ModelAndView("userPgOne");

		} else {
			System.out.println(search);
			List<SearchResultDTO> serchResList = new ArrayList<SearchResultDTO>();
			serchResList = airSer.searchFl(search);
			airSer.insertSer(serchResList);
			System.out.println(serchResList);
			if (!serchResList.isEmpty()) {
				return new ModelAndView("searchResults", "flightsSerch",
						serchResList);
			} else {
				return new ModelAndView("AdminErrorPage", "error",
						"No flights found for your Search.");
			}

			// return "success";
		}

	}

	@RequestMapping(value = "Select Flight", method = RequestMethod.POST)
	public ModelAndView searchDate(
			@ModelAttribute("my") BookingInformationDTO book,
			@RequestParam("fid") String flightNo) {
		// System.out.println("Id is "+id);

		// List<SearchResultDTO> searchedFlight=airSer.select(flightNo);
		SearchResultDTO searchedFlight = airSer.select(flightNo);
		System.out.println("selected" + searchedFlight);
		System.out.println(searchedFlight.getTotTickets());
		return new ModelAndView("BookInfo", "flightSelected", searchedFlight);

	}

	@RequestMapping(value = "Book", method = RequestMethod.POST)
	public ModelAndView flightBook(
			@Valid @ModelAttribute("my") BookingInformationDTO book,
			FlightInformationDTO flight, SearchResultDTO searchedFlight,
			BookingsDbDTO bookings, BindingResult result,
			Map<String, Object> model) throws ARSException {
		int bookId = 0;
		if (result.hasErrors()) {
			// SearchResultDTO searchedFlight=airSer.select(flightNo);
			return new ModelAndView("BookInfo");

		} else {
			System.out.println(book);
			int num = book.getNoOfPassengers();
			String type = book.getClassType();
			String flightNo = book.getFlightNum();
			String mail = book.getCustEmail();
			bookId = airSer.bookDb(book);
			System.out.println("booked");
			airSer.update(flightNo, num, type);
			System.out.println("updated flightinfo");
			airSer.clearSearch();
			System.out.println("seacrh cleared");

			bookings.setBookingId(bookId);
			bookings.setFlightNo(flightNo);
			bookings.setCustName(mail);
			bookings.setNoOfPassengers(num);
			airSer.updateBookings(bookings);
			System.out.println("update bookings");

			return new ModelAndView("report", "bid", bookId);

			// return "success";
		}

	}

	@RequestMapping(value = "cancel", method = RequestMethod.POST)
	public ModelAndView cancel(@RequestParam("bookingid") String bookingId) {
		BookingInformationDTO bookinf = new BookingInformationDTO();
		int bookId = Integer.parseInt(bookingId);
		try {
			bookinf = airSer.getBookInfo(bookId);
			System.out.println("bookInfo done");
			if (bookinf != null) {
				int nos = bookinf.getNoOfPassengers();
				String classType = bookinf.getClassType();
				String fnum = airSer.getFlightNumber(bookId);
				System.out.println("flightnum done" + fnum);
				airSer.updateOnCancel(nos, classType, fnum);
				int cacelStatus = airSer.cancelTicket(bookId);
				if (cacelStatus == 1) {
					return new ModelAndView("cancelled", "cancelled",
							"Cancelled your ticket with booking id:" + bookId);

				} else {
					return new ModelAndView("AdminErrorPage", "error",
							"No Bookings found for your id.");
				}
			} else {
				return new ModelAndView("userPgOne");
			}
		} catch (Exception e) {
			return new ModelAndView("AdminErrorPage", "error",
					"No Bookings found for your id.");
		}
	}

	@RequestMapping(value = "search1", method = RequestMethod.POST)
	public ModelAndView viewreser(@RequestParam("email1") String email,
			@RequestParam("bookingid") String bookingId) {
		BookingInformationDTO bookinf = new BookingInformationDTO();
		System.out.println(email);
		System.out.println(bookingId);
		int bookId = Integer.parseInt(bookingId);
		try {
			bookinf = airSer.viewreser(email, bookId);
		} catch (NoResultException | NumberFormatException e) {
			return new ModelAndView("AdminErrorPage", "error",
					"No flights found for your Search.");
		}
		if (bookinf != null) {
			return new ModelAndView("Bookingresults", "bookinf", bookinf);
		} else {
			return new ModelAndView("AdminErrorPage", "error",
					"Check your booking Id or email");
		}

	}

	@RequestMapping(value = "Menu View Flights", method = RequestMethod.GET)
	public ModelAndView viewFlight() {
		List<FlightInformationDTO> flightList = new ArrayList<FlightInformationDTO>();
		try {
			flightList = airSer.viewFlight();
			if (!flightList.isEmpty()) {
				return new ModelAndView("AdminViewFlights", "flights",
						flightList);
			} else {
				return new ModelAndView("AdminErrorPage");
			}

		} catch (ARSException e) {
			e.printStackTrace();
			return new ModelAndView("AdminErrorPage");
		}

	}

	@RequestMapping(value = "Menu View Reservation", method = RequestMethod.GET)
	public ModelAndView viewBookingInfo() {
		List<BookingInformationDTO> bookingList = new ArrayList<BookingInformationDTO>();
		try {
			bookingList = airSer.viewBookingInfo();
			if (!bookingList.isEmpty()) {
				return new ModelAndView("AdminViewResrvn", "bookInf",
						bookingList);
			} else {
				return new ModelAndView("AdminErrorPage");
			}
		} catch (ARSException e) {
			e.printStackTrace();
			return new ModelAndView("AdminErrorPage");
		}

	}

	@RequestMapping(value = "Report View", method = RequestMethod.GET)
	public String reportView() {

		return "reportview";
	}

	@RequestMapping(value = "Admin Report", method = RequestMethod.POST)
	public String adminReport(@RequestParam("radio") String option) {

		if (option.equals("option1")) {
			return "searchPgOne";
		} else if (option.equals("option2")) {
			return "SearchPgTwo";
		}
		return null;
	}

	@RequestMapping(value = "Admin Search One", method = RequestMethod.POST)
	public ModelAndView adminSearchOne(@RequestParam("date") String date,
			@RequestParam("place") String place) {

		List<FlightInformationDTO> searchResultsOne = new ArrayList<FlightInformationDTO>();
		Date date1 = Date.valueOf(date);
		try {
			searchResultsOne = airSer.adminSearchOne(date1, place);
			if (!searchResultsOne.isEmpty()) {
				return new ModelAndView("results1", "flights", searchResultsOne);
			} else {
				return new ModelAndView("AdminErrorPage", "error",
						"No flights found for your Search.");
			}

		} catch (Exception e) {
			return new ModelAndView("AdminErrorPage", "error",
					"No flights found for your Search.");
		}

	}

	@RequestMapping(value = "Admin Search Two", method = RequestMethod.POST)
	public ModelAndView adminSearchOne(@RequestParam("fnumber") String flightNum) {

		List<BookingsDbDTO> searchResultsTwo = new ArrayList<BookingsDbDTO>();
		try {
			searchResultsTwo = airSer.adminSearchTwo(flightNum);
			if (!searchResultsTwo.isEmpty()) {
				return new ModelAndView("results2", "flights", searchResultsTwo);
			} else {
				return new ModelAndView("AdminErrorPage", "error",
						"No flights found for your Search.");
			}
		} catch (Exception e) {
			return new ModelAndView("AdminErrorPage", "error",
					"No flights found for your Search.");
		}

	}

	@RequestMapping(value = "sourcedest", method = RequestMethod.GET)
	public String showData(@ModelAttribute("my") FlightInformationDTO flight,
			BindingResult result, Map<String, Object> model) {
		List<String> myCities = new ArrayList<String>();
		System.out.println("hi");
		myCities.add("CHENNAI");
		myCities.add("PUNE");
		myCities.add("MUMBAI");
		myCities.add("DELHI");

		model.put("myCities1", myCities);

		return "sourcedest";

	}

	@RequestMapping(value = "showsrcdest", method = RequestMethod.POST)
	public ModelAndView dataAdd(
			@Valid @ModelAttribute("my") FlightInformationDTO flight,
			BindingResult result, Map<String, Object> model, String dep_city,
			String arr_city) {
		try {
			List<FlightInformationDTO> fdto = airSer.showAll1(dep_city,
					arr_city);
			System.out.println(fdto);
			if (!fdto.isEmpty()) {
				return new ModelAndView("details1", "fdto", fdto);
			} else {
				return new ModelAndView("AdminErrorPage", "error",
						"No flights found for your Search.");
			}
		} catch (Exception e) {
			return new ModelAndView("AdminErrorPage", "error",
					"No flights found for your Search.");
		}
	}

	@RequestMapping(value = "dateperiod", method = RequestMethod.GET)
	public String showdateperiod(
			@ModelAttribute("my") FlightInformationDTO flight,
			BindingResult result, Map<String, Object> model) {

		return "dateperiod";

	}

	@RequestMapping(value = "dateperiod1", method = RequestMethod.GET)
	public ModelAndView showData1(
			@ModelAttribute("my") FlightInformationDTO flight,
			BindingResult result, Map<String, Object> model,
			@RequestParam("tempDate") Date tempDate, Date dep_date) {
		System.out.println("hi2");
		try {
			List<FlightInformationDTO> fdto1 = airSer.showAllDate(tempDate,
					dep_date);
			System.out.println(fdto1);

			if (!fdto1.isEmpty()) {
				return new ModelAndView("details2", "fdto1", fdto1);
			} else {
				return new ModelAndView("AdminErrorPage", "error",
						"No flights found for your Search.");
			}
		} catch (Exception e) {
			return new ModelAndView("AdminErrorPage", "error",
					"No flights found for your Search.");
		}

	}

}
