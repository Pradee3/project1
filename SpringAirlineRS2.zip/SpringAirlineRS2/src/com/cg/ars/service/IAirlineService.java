package com.cg.ars.service;

import java.sql.Date;
import java.util.List;

import com.cg.ars.dto.BookingInformationDTO;
import com.cg.ars.dto.BookingsDbDTO;
import com.cg.ars.dto.FlightInformationDTO;
import com.cg.ars.dto.LoginTypeDTO;
import com.cg.ars.dto.SearchDTO;
import com.cg.ars.dto.SearchResultDTO;
import com.cg.ars.exception.ARSException;

public interface IAirlineService  {
	
	public LoginTypeDTO login(String userName);
	
	public void signUp(LoginTypeDTO signUp) throws ARSException;
	
	/*public String login(String username,String password);
	
	public String loginCustomer(String username,String password);
	*/
	public void insertFlight(FlightInformationDTO flight) throws ARSException;
	
	//public List<FlightInformationDTO> viewFlight() throws ARSException;
	
	/*public List<BookingInformationDTO> viewBookingInfo() throws ARSException;
	
	*/
	
	public List<SearchResultDTO> searchFl(SearchDTO search);
	
	/*public SearchResultDTO bookDisp(int no);
	
	*/public void insertSer(List<SearchResultDTO> serdata);
	
	//public List<SearchResultDTO> select(String flightNo);
	public SearchResultDTO select(String flightNo);
	
	public int bookDb(BookingInformationDTO book) throws ARSException;
	
	public void clearSearch();
	
	public void update(String flightnum,int numbers,String type);
	
	public void updateBookings(BookingsDbDTO bookings);
	/*public List<FlightInformationDTO> adminSearchOne(Date date,String place);
	
	public void updateCustomers(int id, String mail,String uname);
	
	public List<BookingsDbDTO> adminSearchTwo(String flightNum);
	
	public List<FlightInformationDTO> showexecDetails(String src,String dest);
	public List<FlightInformationDTO> showexecDetailsPeriodDB(Date date1,Date date2);
	public List<BookingInformationDTO> showbookingInfo(String email,String bookingid);
	*/
	public String getFlightNumber(int bookingid);
	
	/*public int getBookingidSession(String username);
	
	*/public BookingInformationDTO getBookInfo(int bookid2);
	
	public void updateOnCancel(int nos, String classType,String fnum);
	
	public int cancelTicket(int bookid2);
	public BookingInformationDTO viewreser(String email,int bookingId);
	public List<FlightInformationDTO> viewFlight() throws ARSException;

	public List<BookingInformationDTO> viewBookingInfo() throws ARSException;

	public List<FlightInformationDTO> adminSearchOne(Date date1, String place) throws ARSException;

	public List<BookingsDbDTO> adminSearchTwo(String flightNum) throws ARSException;
	public List<FlightInformationDTO> showAll1(String dep_city,String arr_city);
	public List<FlightInformationDTO> showAllDate(Date dep_date,Date tempDate);

	
	/*public String getFlightInfo(String flightnum,String type);
	*/
	/*public int createSeq(int seatN, String flightnum);*/
	
	
	
}
