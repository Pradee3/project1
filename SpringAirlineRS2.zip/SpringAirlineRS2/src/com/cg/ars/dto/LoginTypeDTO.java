package com.cg.ars.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="LOGINTYPE")
public class LoginTypeDTO {
	@Id @Column(name="USERNAME")
	@NotEmpty(message="Name field can't be Empty")
	@Pattern(regexp="[A-Z][a-z]{3,20}")
	private String username;
	@Column(name="PASSWORD")
	@NotEmpty(message="Password Field can't be Empty")
	private String password;
	@Column(name="ROLE")
	private String role;
	@Column(name="MOBILENO")
	@NotEmpty(message="Contact Field cant be Empty")
	@Pattern(regexp="[9]{1}[0-9]{9}")
	private String mobileNo;
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	
	
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	@Override
	public String toString() {
		return "LoginTypeDTO [username=" + username + ", password=" + password
				+ ", role=" + role + ", mobileNo=" + mobileNo + "]";
	}
	
	
	

	
	
	
}
