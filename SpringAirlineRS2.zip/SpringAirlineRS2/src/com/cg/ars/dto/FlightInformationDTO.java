package com.cg.ars.dto;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Type;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.datetime.joda.LocalDateParser;


@Entity
@Table(name="FLIGHTINFORMATION")
public class FlightInformationDTO {
	
	@Id @Column(name="flightno")
	private String flightNo;
	
	@Column(name="airline")
	@NotEmpty(message="Field cannot be empty")
	private String airline;
	
	@Column(name="dep_city")
	@NotEmpty(message="Field cannot be empty")
	private String dep_city;
	
	@Column(name="arr_city")
	@NotEmpty(message="Field cannot be empty")
	private String arr_city;
	
	@Column(name="dep_date")
	/*@DateTimeFormat(pattern="dd/MM/YY")
	@Type(type="date")
	@NotEmpty(message="Field cannot be empty")*/
	private Date dep_date;
	
	@Column(name="arr_date")
	/*@DateTimeFormat(pattern="dd/MM/YY")
	@Type(type="date")
	@NotEmpty(message="Field cannot be empty")*/
	private Date arr_date;
	
	@Column(name="dep_time")
	@NotEmpty(message="Field cannot be empty")
	private String dep_time;
	
	@Column(name="arr_time")
	@NotEmpty(message="Field cannot be empty")
	private String arr_time;
	
	@Column(name="FIRSTSEATS")
	@NotNull(message="Field cannot be empty")
	private Integer firstSeats;
	
	@Column(name=" FIRSTSEATFARE")
	@NotNull(message="Field cannot be empty")
	private Double firstSeatsFare;
	
	@Column(name="BUSSSEATS")
	@NotNull(message="Field cannot be empty")
	private Integer busSeats;
	
	@Column(name=" BUSSSEATSFARE")
	@NotNull(message="Field cannot be empty")
	private Double busSeatsFare;
	@Transient
	private Date tempDate;
	
	public Date getTempDate() {
		return tempDate;
	}

	public void setTempDate(Date tempDate) {
		this.tempDate = tempDate;
	}

	public FlightInformationDTO() {
		super();
	}

	public FlightInformationDTO(String flightNo, String airline, String dep_city,
			String arr_city, Date dep_date, Date arr_date, String dep_time,
			String arr_time, Integer firstSeats, Double firstSeatsFare,
			Integer busSeats, Double busSeatsFare) {
		super();
		this.flightNo = flightNo;
		this.airline = airline;
		this.dep_city = dep_city;
		this.arr_city = arr_city;
		this.dep_date = dep_date;
		this.arr_date = arr_date;
		this.dep_time = dep_time;
		this.arr_time = arr_time;
		this.firstSeats = firstSeats;
		this.firstSeatsFare = firstSeatsFare;
		this.busSeats = busSeats;
		this.busSeatsFare = busSeatsFare;
	}

	public String getFlightNo() {
		return flightNo;
	}

	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}

	public String getAirline() {
		return airline;
	}

	public void setAirline(String airline) {
		this.airline = airline;
	}

	public String getDep_city() {
		return dep_city;
	}

	public void setDep_city(String dep_city) {
		this.dep_city = dep_city;
	}

	public String getArr_city() {
		return arr_city;
	}

	public void setArr_city(String arr_city) {
		this.arr_city = arr_city;
	}

	public Date getDep_date() {
		return dep_date;
	}

	public void setDep_date(Date dep_date) {
		this.dep_date = dep_date;
	}

	public Date getArr_date() {
		return arr_date;
	}

	public void setArr_date(Date arr_date) {
		this.arr_date = arr_date;
	}

	public String getDep_time() {
		return dep_time;
	}

	public void setDep_time(String dep_time) {
		this.dep_time = dep_time;
	}

	public String getArr_time() {
		return arr_time;
	}

	public void setArr_time(String arr_time) {
		this.arr_time = arr_time;
	}

	public Integer getFirstSeats() {
		return firstSeats;
	}

	public void setFirstSeats(Integer firstSeats) {
		this.firstSeats = firstSeats;
	}

	public Double getFirstSeatsFare() {
		return firstSeatsFare;
	}

	public void setFirstSeatsFare(Double firstSeatsFare) {
		this.firstSeatsFare = firstSeatsFare;
	}

	public Integer getBusSeats() {
		return busSeats;
	}

	public void setBusSeats(Integer busSeats) {
		this.busSeats = busSeats;
	}

	public Double getBusSeatsFare() {
		return busSeatsFare;
	}

	public void setBusSeatsFare(Double busSeatsFare) {
		this.busSeatsFare = busSeatsFare;
	}

	@Override
	public String toString() {
		return "FlightInformationDTO [flightNo=" + flightNo + ", airline="
				+ airline + ", dep_city=" + dep_city + ", arr_city=" + arr_city
				+ ", dep_date=" + dep_date + ", arr_date=" + arr_date
				+ ", dep_time=" + dep_time + ", arr_time=" + arr_time
				+ ", firstSeats=" + firstSeats + ", firstSeatsFare="
				+ firstSeatsFare + ", busSeats=" + busSeats + ", busSeatsFare="
				+ busSeatsFare + ", tempDate=" + tempDate + "]";
	}
	
}
