package com.cg.ars.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bookingsdb")
public class BookingsDbDTO {

	@Id @Column(name="BOOKING_ID")
	public int bookingId;
	@Column(name="FLIGHTNO")
	public String flightNo;
	@Column(name="MAIL")
	public String custName;
	@Column(name="NO_OF_PASSENGERS")
	public int noOfPassengers;
	
	@Override
	public String toString() {
		return "BookingsDbDTO [bookingId=" + bookingId + ", flightNo="
				+ flightNo + ", custName=" + custName + ", noOfPassengers="
				+ noOfPassengers + "]";
	}
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public String getFlightNo() {
		return flightNo;
	}
	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public int getNoOfPassengers() {
		return noOfPassengers;
	}
	public void setNoOfPassengers(int noOfPassengers) {
		this.noOfPassengers = noOfPassengers;
	}
	
	
}
