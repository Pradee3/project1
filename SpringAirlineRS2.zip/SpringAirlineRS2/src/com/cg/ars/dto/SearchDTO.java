package com.cg.ars.dto;

import java.sql.Date;

public class SearchDTO {
	
	String src;
	String destn;
	Date start;
	Date end;
	int infants;
	int adults;
	String type;
	String trip;
	
	public String getTrip() {
		return trip;
	}
	public void setTrip(String trip) {
		this.trip = trip;
	}
	public String getSrc() {
		return src;
	}
	public void setSrc(String src) {
		this.src = src;
	}
	public String getDestn() {
		return destn;
	}
	public void setDestn(String destn) {
		this.destn = destn;
	}
	public Date getStart() {
		return start;
	}
	public void setStart(Date start) {
		this.start = start;
	}
	public Date getEnd() {
		return end;
	}
	public void setEnd(Date end) {
		this.end = end;
	}
	public int getInfants() {
		return infants;
	}
	public void setInfants(int infants) {
		this.infants = infants;
	}
	public int getAdults() {
		return adults;
	}
	public void setAdults(int adults) {
		this.adults = adults;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	@Override
	public String toString() {
		return "SearchDTO [src=" + src + ", destn=" + destn + ", start="
				+ start + ", end=" + end + ", infants=" + infants + ", adults="
				+ adults + ", type=" + type + ", trip=" + trip + "]";
	}
	
	

}
