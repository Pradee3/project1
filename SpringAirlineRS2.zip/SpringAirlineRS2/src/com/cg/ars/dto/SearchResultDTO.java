package com.cg.ars.dto;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="searchdb")
public class SearchResultDTO {
	
	@Id @Column(name="flightno")
	private String flightNo;
	@Column(name="airline")
	private String airline;
	@Column(name="source")
	private String src;
	@Column(name="destn")
	private String destn;
	@Column(name="tot_fare")
	private double total_fare;
	@Column(name="tot_tickets")
	private int totTickets;
	@Column(name="class_type")
	private String type;
	@Transient
	private Date dep_date;
	@Transient
	private String dep_time;
	@Transient
	private String arr_time;
	@Transient
	private String firstSeats;
	@Transient
	private String busSeats;
	@Transient
	private double seatsFare;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public int getTotTickets() {
		return totTickets;
	}
	public void setTotTickets(int totTickets) {
		this.totTickets = totTickets;
	}
	
	public String getFirstSeats() {
		return firstSeats;
	}
	public void setFirstSeats(String firstSeats) {
		this.firstSeats = firstSeats;
	}
	public String getBusSeats() {
		return busSeats;
	}
	public void setBusSeats(String busSeats) {
		this.busSeats = busSeats;
	}
	
	
	public String getFlightNo() {
		return flightNo;
	}
	public void setFlightNo(String flightNo2) {
		this.flightNo = flightNo2;
	}
	public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
	public String getSrc() {
		return src;
	}
	public void setSrc(String src) {
		this.src = src;
	}
	public String getDestn() {
		return destn;
	}
	public void setDestn(String destn) {
		this.destn = destn;
	}
	public double getTotal_fare() {
		return total_fare;
	}
	public void setTotal_fare(double total_fare) {
		this.total_fare = total_fare;
	}
	public double getSeatsFare() {
		return seatsFare;
	}
	public void setSeatsFare(double seatsFare) {
		this.seatsFare = seatsFare;
	}
	
	public Date getDep_date() {
		return dep_date;
	}
	public void setDep_date(Date dep_date) {
		this.dep_date = dep_date;
	}
	public String getDep_time() {
		return dep_time;
	}
	public void setDep_time(String dep_time) {
		this.dep_time = dep_time;
	}
	@Override
	public String toString() {
		return "SearchResultDTO [flightNo=" + flightNo + ", airline=" + airline
				+ ", src=" + src + ", destn=" + destn + ", total_fare="
				+ total_fare + ", totTickets=" + totTickets + ", type=" + type
				+ ", dep_date=" + dep_date + ", dep_time=" + dep_time
				+ ", arr_time=" + arr_time + ", firstSeats=" + firstSeats
				+ ", busSeats=" + busSeats + ", seatsFare=" + seatsFare + "]";
	}
	public String getArr_time() {
		return arr_time;
	}
	public void setArr_time(String arr_time) {
		this.arr_time = arr_time;
	}
	
	
 
	
}
