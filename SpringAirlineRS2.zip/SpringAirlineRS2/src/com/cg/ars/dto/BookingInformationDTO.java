package com.cg.ars.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Required;

@Entity
@Table(name="BOOKINGINFORMATION")
public class BookingInformationDTO {
	
	@Id @GeneratedValue(strategy=GenerationType.SEQUENCE,generator="hibernateseq")
	@SequenceGenerator(name="hibernateseq",sequenceName="booking_seq")
	@Column(name="BOOKING_ID")
	private int bookingId;
	
	@Column(name="CUST_EMAIL")
	@Email(message="Please enter valid Email ID")
	@NotEmpty(message="Field cannot be empty")	
	private String custEmail;
	
	@Column(name="NO_OF_PASSENGERS")
	private int noOfPassengers;
	
	@Column(name="CLASS_TYPE")
	private String classType;
	
	@Column(name="TOTAL_FARE")
	private Double totalFare;
	
	@Column(name=" SEAT_NUMBER")
	private String seatNumbers;
	
	@Column(name="CREDITCARD_INFO")
	@NotEmpty(message="Credit card number cannot be empty")
	@Size(min=10,max=10,message="Credit Card Number Should Accpet Only 10 digits")
	@Pattern(regexp="^[0-9]{10}$",message="Credit card no. should contain only 10 digits")	
	private String creditCardInfo;
	
	@Column(name="SRC_CITY")
	private String srcCity;
	
	@Column(name="DEST_CITY")
	private String destCity;
	
	@Transient
	private String flightNum;
	
	public String getFlightNum() {
		return flightNum;
	}
	public void setFlightNum(String flightNum) {
		this.flightNum = flightNum;
	}
	public BookingInformationDTO() {
		super();
	}
	public BookingInformationDTO(int bookingId, String custEmail,
			int noOfPassengers, String classType, Double totalFare,
			String seatNumbers, String creditCardInfo, String srcCity,
			String destCity) {
		super();
		this.bookingId = bookingId;
		this.custEmail = custEmail;
		this.noOfPassengers = noOfPassengers;
		this.classType = classType;
		this.totalFare = totalFare;
		this.seatNumbers = seatNumbers;
		this.creditCardInfo = creditCardInfo;
		this.srcCity = srcCity;
		this.destCity = destCity;
	}
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public String getCustEmail() {
		return custEmail;
	}
	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}
	public int getNoOfPassengers() {
		return noOfPassengers;
	}
	public void setNoOfPassengers(int noOfPassengers) {
		this.noOfPassengers = noOfPassengers;
	}
	public String getClassType() {
		return classType;
	}
	public void setClassType(String classType) {
		this.classType = classType;
	}
	public Double getTotalFare() {
		return totalFare;
	}
	public void setTotalFare(Double totalFare) {
		this.totalFare = totalFare;
	}
	public String getSeatNumbers() {
		return seatNumbers;
	}
	public void setSeatNumbers(String seatNumbers) {
		this.seatNumbers = seatNumbers;
	}
	public String getCreditCardInfo() {
		return creditCardInfo;
	}
	public void setCreditCardInfo(String creditCardInfo) {
		this.creditCardInfo = creditCardInfo;
	}
	public String getSrcCity() {
		return srcCity;
	}
	public void setSrcCity(String srcCity) {
		this.srcCity = srcCity;
	}
	public String getDestCity() {
		return destCity;
	}
	public void setDestCity(String destCity) {
		this.destCity = destCity;
	}
	
	@Override
	public String toString() {
		return "BookingInformationDTO [bookingId=" + bookingId + ", custEmail="
				+ custEmail + ", noOfPassengers=" + noOfPassengers
				+ ", classType=" + classType + ", totalFare=" + totalFare
				+ ", seatNumbers=" + seatNumbers + ", creditCardInfo="
				+ creditCardInfo + ", srcCity=" + srcCity + ", destCity="
				+ destCity + ", flightNum=" + flightNum + "]";
	}
	
	

}
