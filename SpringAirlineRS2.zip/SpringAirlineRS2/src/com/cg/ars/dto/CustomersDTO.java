package com.cg.ars.dto;

public class CustomersDTO {

	public String name;
	public String password;
	public String mobile;
	public String custMail;
	public String status;
	public String bookingId;
	public String role;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getCustMail() {
		return custMail;
	}
	public void setCustMail(String custMail) {
		this.custMail = custMail;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getBookingId() {
		return bookingId;
	}
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "CustomersDTO [name=" + name + ", password=" + password
				+ ", mobile=" + mobile + ", custMail=" + custMail + ", status="
				+ status + ", bookingId=" + bookingId + ", role=" + role + "]";
	}
	
	
	
	
}
