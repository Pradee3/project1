package com.cg.ars.exception;

public class ARSException extends Exception{
	
	public ARSException(String message)
	{
		super(message);
	}
	
	public ARSException()
	{
		super();
	}
	

}
