package com.cg.ars.dao;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.ars.dto.BookingInformationDTO;
import com.cg.ars.dto.BookingsDbDTO;
import com.cg.ars.dto.FlightInformationDTO;
import com.cg.ars.dto.LoginTypeDTO;
import com.cg.ars.dto.SearchDTO;
import com.cg.ars.dto.SearchResultDTO;
import com.cg.ars.exception.ARSException;



@Repository("airDao")
public class AirlineDAO implements IAirlineDAO{

	
	@Override
	public LoginTypeDTO loginDb(String userName) {
		// TODO Auto-generated method stub
		LoginTypeDTO loginType=new LoginTypeDTO();
		Query queryOne=entitymanager.createQuery("from LoginTypeDTO where username=:username",LoginTypeDTO.class);
		queryOne.setParameter("username",userName);
		loginType=(LoginTypeDTO) queryOne.getSingleResult();
		return loginType;
	}
	

	@Override
	public void signUp(LoginTypeDTO signUp) throws ARSException {
		// TODO Auto-generated method stub
		signUp.setRole("USER");
		entitymanager.persist(signUp);		
		entitymanager.flush();
	}

	
	@PersistenceContext
	EntityManager entitymanager;
	/*@Override
	public void flightDb(FlightInformationDTO flight) throws ARSException {
		// TODO Auto-generated method stub
		entitymanager.persist(flight);
		entitymanager.flush();
		
		
	}

	@Override
	public List<FlightInformationDTO> viewFlightDb() throws ARSException {
		// TODO Auto-generated method stub
		return null;
	}
*/
	@Override
	public List<FlightInformationDTO> searchFl(SearchDTO search) {
		
		Query queryOne=null;
		String type = search.getType();
		System.out.println("in seacrh dao");
		List<FlightInformationDTO> myList = new ArrayList<FlightInformationDTO>();
		if (type.equalsIgnoreCase("FC")) {
			queryOne=entitymanager.createQuery("FROM FlightInformationDTO where dep_city=:DEP_CITY AND arr_city=:ARR_CITY AND dep_date=:DEP_DATE AND firstSeats>=:FIRSTSEATS");
			queryOne.setParameter("DEP_CITY", search.getSrc());
			queryOne.setParameter("ARR_CITY", search.getDestn());
			queryOne.setParameter("DEP_DATE", search.getStart());
			int infSeats = search.getInfants();
			int adlSeats = search.getAdults();
			int total = infSeats + adlSeats;
			queryOne.setParameter("FIRSTSEATS", total);
			
		}
		else if (type.equalsIgnoreCase("Business")) 
		{
			queryOne=entitymanager.createQuery("FROM FlightInformationDTO where dep_city=:DEP_CITY AND arr_city=:ARR_CITY AND dep_date=:DEP_DATE AND busSeats>=:BUSSSEATS");
			
			queryOne.setParameter("DEP_CITY", search.getSrc());
			queryOne.setParameter("ARR_CITY", search.getDestn());
			queryOne.setParameter("DEP_DATE", search.getStart());
			int infSeats = search.getInfants();
			int adlSeats = search.getAdults();
			int total = infSeats + adlSeats;
			queryOne.setParameter("BUSSSEATS", total);
			}	
		
		List<FlightInformationDTO> myFlightList=queryOne.getResultList();
		return myFlightList;
	}
	
	@Override
	public void insertSer(List<SearchResultDTO> serdata) {
		for (SearchResultDTO searchResultDTO : serdata) {
			entitymanager.persist(searchResultDTO);
			entitymanager.flush();
		}
		
	}

	/*@Override
	public List<SearchResultDTO> select(String flightNo) {
		Query queryOne=entitymanager.createQuery("FROM SearchResultDTO WHERE flightNo=:FLIGHTNO");
		queryOne.setParameter("FLIGHTNO", flightNo);
		List<SearchResultDTO> search=queryOne.getResultList();
		return search;
	}*/
	@Override
	public SearchResultDTO select(String flightNo) {
		Query queryOne=entitymanager.createQuery("FROM SearchResultDTO WHERE flightNo=:FLIGHTNO",SearchResultDTO.class);
		queryOne.setParameter("FLIGHTNO", flightNo);
		SearchResultDTO search= (SearchResultDTO) queryOne.getSingleResult();
		return search;
	}
	@Override
	public int bookDb(BookingInformationDTO book)
			throws ARSException {
		// TODO Auto-generated method stub
		entitymanager.persist(book);
		entitymanager.flush();
		return book.getBookingId();
	}

	@Override
	public void update(String flightnum, int numbers, String type) {
		Query queryOne=null;
		if (type.equalsIgnoreCase("FC")) {
			queryOne = entitymanager.createQuery("UPDATE FlightInformationDTO SET firstSeats=firstSeats-:num WHERE flightNo=:flightno");
		} else if (type.equalsIgnoreCase("Business")) {
			queryOne = entitymanager.createQuery("UPDATE FlightInformationDTO SET busSeats=busSeats-:num WHERE flightNo=:flightno");
		}
		queryOne.setParameter("flightno",flightnum);
		queryOne.setParameter("num",numbers);
		queryOne.executeUpdate();
		
	}

	@Override
	public void clearSearch() {	
		Query queryOne=entitymanager.createQuery("DELETE FROM SearchResultDTO");
		queryOne.executeUpdate();
		
	}

	@Override
	public void updateBookings(BookingsDbDTO bookings) {
		entitymanager.persist(bookings);
		entitymanager.flush();
		
	}

	@Override
	public BookingInformationDTO getBookInfo(int bookid2) {
		Query queryOne=entitymanager.createQuery("FROM BookingInformationDTO WHERE bookingId=:booking_id",BookingInformationDTO.class);
		queryOne.setParameter("booking_id",bookid2);
		BookingInformationDTO bookInf=(BookingInformationDTO) queryOne.getSingleResult();
		return bookInf;
	}

	@Override
	public String getFlightNumberdb(int bookingid) {
		Query queryOne=entitymanager.createQuery("SELECT flightNo FROM BookingsDbDTO WHERE bookingId=:BOOKING_ID");
		queryOne.setParameter("BOOKING_ID",bookingid);
		String flightNo=(String) queryOne.getSingleResult();
		return flightNo;
	}

	@Override
	public void updateOnCancel(int nos, String classType, String fnum) {
		// TODO Auto-generated method stub
		Query queryOne=null;
		if (classType.equalsIgnoreCase("FC")) {
			queryOne = entitymanager.createQuery("UPDATE FlightInformationDTO SET firstSeats=firstSeats+:num WHERE flightNo=:flightno");
		} else if (classType.equalsIgnoreCase("Business")) {
			queryOne = entitymanager.createQuery("UPDATE FlightInformationDTO SET busSeats=busSeats+:num WHERE flightNo=:flightno");
		}
		queryOne.setParameter("flightno",fnum);
		queryOne.setParameter("num",nos);
		queryOne.executeUpdate();
	}

	@Override
	public int cancelTicket(int bookid2) {
	
		Query queryOne=entitymanager.createQuery("DELETE FROM BookingInformationDTO WHERE bookingId=:booking_id ");
		queryOne.setParameter("booking_id",bookid2);
		int status=queryOne.executeUpdate();
		return status;
	}

	@Override
	public BookingInformationDTO viewreser(String email, int bookingId) {
		// TODO Auto-generated method stub
		Query query10=entitymanager.createQuery("FROM BookingInformationDTO where custEmail=:CUST_EMAIL and bookingId=:BOOKING_ID",BookingInformationDTO.class);
		query10.setParameter("CUST_EMAIL", email);
		query10.setParameter("BOOKING_ID", bookingId);
		BookingInformationDTO bidto=(BookingInformationDTO) query10.getSingleResult();
		System.out.println(bidto);
		return bidto;
	}


	@Override
	public void flightDb(FlightInformationDTO flight) throws ARSException {
		
		entitymanager.persist(flight);
		entitymanager.flush();
		
		
	}

	@Override
	public List<FlightInformationDTO> viewFlightDb() throws ARSException {
		
		Query query = entitymanager.createQuery("FROM FlightInformationDTO");
		List<FlightInformationDTO> myList = query.getResultList();
		return myList;
	}
	
	@Override
	public List<BookingInformationDTO> viewBookingInfoDb() throws ARSException {
		
		Query query = entitymanager.createQuery("FROM BookingInformationDTO");
		List<BookingInformationDTO> bookList = query.getResultList();
		return bookList;
	}

	@Override
	public List<FlightInformationDTO> adminSearchOne(Date date, String place)
			throws ARSException {
		
		Query query = entitymanager.createQuery("FROM FlightInformationDTO where dep_date=:dep_date and arr_city=:arr_city");
		query.setParameter("dep_date", date);
		query.setParameter("arr_city", place);
		List<FlightInformationDTO> flightList = query.getResultList();
		return flightList;
	}

	@Override
	public List<BookingsDbDTO> adminSearchTwo(String flightNum)
			throws ARSException {
		
		Query query = entitymanager.createQuery("FROM BookingsDbDTO where flightNo=:FLIGHTNO");
		query.setParameter("FLIGHTNO", flightNum);
		List<BookingsDbDTO> bookingList = query.getResultList();
		return bookingList;
	}
	@Override
	public List<FlightInformationDTO> showAll1db(String dep_city,String arr_city) {
		// TODO Auto-generated method stub
		Query query=entitymanager.createQuery("FROM FlightInformationDTO where dep_city=:dep_city AND arr_city=:arr_city");
		query.setParameter("dep_city", dep_city);
		query.setParameter("arr_city", arr_city);
		List<FlightInformationDTO> myFlight=query.getResultList();
		System.out.println(myFlight);
		return myFlight;
	}

	@Override
	public List<FlightInformationDTO> showAllDatedb(Date dep_date,Date tempDate) {
		// TODO Auto-generated method stub
		System.out.println("in dao");
		System.out.println(dep_date);
		System.out.println(tempDate);
		/*SimpleDateFormat format = new SimpleDateFormat("dd-mon-yyyy");
		String frmDate = format.format(dep_date);
		String enDate = format.format(tempDate);*/
		Query query2=entitymanager.createQuery("FROM FlightInformationDTO where dep_date IN( :dep_date , :tempDate)");
		//Query query2=entitymanager.createQuery("FROM FlightInformationDTO where dep_date between :dep_date AND :tempDate");
		query2.setParameter("dep_date",dep_date );
		query2.setParameter("tempDate",tempDate);
		//Query query2=entitymanager.createQuery("FROM FlightInformationDTO where dep_date between '"+frmDate+"' and '"+enDate+"'");
		List<FlightInformationDTO> myFlight1=query2.getResultList();
		System.out.println(myFlight1);
		return myFlight1;
	}

	
	
}
