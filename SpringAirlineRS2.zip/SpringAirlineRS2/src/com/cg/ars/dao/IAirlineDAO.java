package com.cg.ars.dao;


import java.sql.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.ars.dto.BookingInformationDTO;
import com.cg.ars.dto.BookingsDbDTO;
import com.cg.ars.dto.FlightInformationDTO;
import com.cg.ars.dto.LoginTypeDTO;
import com.cg.ars.dto.SearchDTO;
import com.cg.ars.dto.SearchResultDTO;
import com.cg.ars.exception.ARSException;


public interface IAirlineDAO {
	
	public LoginTypeDTO loginDb(String userName);
	
	public void signUp(LoginTypeDTO signUp) throws ARSException;
	
	public void flightDb(FlightInformationDTO flight) throws ARSException;
	
	//public List<FlightInformationDTO> viewFlightDb() throws ARSException;
	
	/*public List<BookingInformationDTO> viewBookingInfoDb() throws ARSException;
	
	*/
	
	public List<FlightInformationDTO> searchFl(SearchDTO search);
	
	public void insertSer(List<SearchResultDTO> serdata);
	
	//public List<SearchResultDTO> select(String flightNo);
	
	public SearchResultDTO select(String flightNo);
	public int bookDb(BookingInformationDTO book) throws ARSException;
	
	public void clearSearch();
	
	public void update(String flightnum,int numbers,String type);
	
	public void updateBookings(BookingsDbDTO bookings);
	
	
	/*public List<FlightInformationDTO> adminSearchOne(Date date, String place);
	
	public void updateCustomers(int id, String mail,String uname);

	public List<BookingsDbDTO> adminSearchTwo(String flightNum);
	
	public List<FlightInformationDTO> showexecDetailsDB(String src,String dest);
	public List<FlightInformationDTO> showexecDetailsPeriodDB(Date date1,Date date2);
	public List<BookingInformationDTO> showbookingInfo(String email,String bookingid);
	*/
	public String getFlightNumberdb(int bookingid);
	
	/*public int getBookingidSession(String username);
	
	*/public BookingInformationDTO getBookInfo(int bookid2);
	
	public void updateOnCancel(int nos, String classType,String fnum);
	
	public int cancelTicket(int bookid2);
	public BookingInformationDTO viewreser(String email, int bookingId);
public List<FlightInformationDTO> viewFlightDb() throws ARSException;
	
	public List<BookingInformationDTO> viewBookingInfoDb() throws ARSException;

	public List<FlightInformationDTO> adminSearchOne(Date date, String place) throws ARSException;

	public List<BookingsDbDTO> adminSearchTwo(String flightNum) throws ARSException;
	
	public List<FlightInformationDTO> showAll1db(String dep_city,String arr_city);
	public List<FlightInformationDTO> showAllDatedb(Date dep_date,Date tempDate);
	
	/*
	public String getFlightInfo(String flightnum,String type);
	*/
	/*public int createSeq(int seatN, String flightnum);*/

	
}
