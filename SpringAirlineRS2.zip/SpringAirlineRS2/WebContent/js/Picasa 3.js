function displayTextBox()
        {
            document.getElementById('returndate').style.display = 'block'; 
        }
		
		function hideTextBox()
		{
			document.getElementById('returndate').style.display = 'none'; 
		}
function Validatefunc() {
        var source = document.getElementById("src").value;
        var destination = document.getElementById("dst").value;
        if (source == destination) {
        	/*flag.innerText="Error! Source and destination cannot be same."*/
        	alert("Error! Source and destination cannot be same.");
        	document.getElementById("dst").value="";
        	//window.location.reload();
            return false;
        }
        return true;
    }

function validDate(date, theInput) {
    var date = document.getElementById("departdate").value;
    todayDate = getTodaysDate();
    if (date < todayDate)
        theInput.value = todayDate;
}
function ol()
{
document.getElementById("departdate").valueAsDate = new Date()
}
function getTodaysDate(){
    date = new Date();
    day = date.getDate();
    month = date.getMonth() + 1;
    year = date.getFullYear();

    if (month < 10) month = "0" + month;
    if (day < 10) day = "0" + day;

    today = year + "-" + month + "-" + day; 

    return today;
}
function validDate11(date, theInput) {
    var date = document.getElementById("dep_date").value;
    todayDate = getTodaysDate();
    if (date < todayDate)
        theInput.value = todayDate;
}
function ol()
{
document.getElementById("dep_date").valueAsDate = new Date()
}
function getTodaysDate(){
    date = new Date();
    day = date.getDate();
    month = date.getMonth() + 1;
    year = date.getFullYear();

    if (month < 10) month = "0" + month;
    if (day < 10) day = "0" + day;

    today = year + "-" + month + "-" + day; 

    return today;
}
function validDate12(date, theInput) {
    var date = document.getElementById("arr_date").value;
    todayDate = getTodaysDate();
    if (date < todayDate)
        theInput.value = todayDate;
}
function ol()
{
document.getElementById("arr_date").valueAsDate = new Date()
}
function getTodaysDate(){
    date = new Date();
    day = date.getDate();
    month = date.getMonth() + 1;
    year = date.getFullYear();

    if (month < 10) month = "0" + month;
    if (day < 10) day = "0" + day;

    today = year + "-" + month + "-" + day; 

    return today;
}
function validDate23(date, theInput) {
    var date = document.getElementById("returndate").value;
    todayDate = getTodaysDate();
    if (date < todayDate)
        theInput.value = todayDate;
}
function ol()
{
document.getElementById("returndate").valueAsDate = new Date()
}
function getTodaysDate(){
    date = new Date();
    day = date.getDate();
    month = date.getMonth() + 1;
    year = date.getFullYear();

    if (month < 10) month = "0" + month;
    if (day < 10) day = "0" + day;

    today = year + "-" + month + "-" + day; 

    return today;
}
function myFunction() {
    var x = document.getElementById('myDIV');
    if (x.style.display === 'none') {
        x.style.display = 'block';
    } else {
        x.style.display = 'none';
    }
}